void testaVariacao(int);

int testaFluxo(int);

int testaLinhas(int);

int testaMargem(int);
