
void meuSleep(int ms);

void* mallocSafe(size_t);
