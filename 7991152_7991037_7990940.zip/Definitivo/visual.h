#ifndef VISUAL_H
#define VISUAL_H

#define VISUAL_FAIL 0
#define VISUAL_SUCCESS 1


int visualInit(Rio, int, int);



#endif
